﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Vendas.Models;
using Vendas.Models.Enums;

namespace Vendas.Data
{
    public class SeedingService
    {
        private VendasContext _context;

        public SeedingService(VendasContext context)
        {
            _context = context;
        }

        public void Seed()
        {
            if (_context.department.Any() ||
                _context.Sellers.Any() ||
                _context.SalesRecord.Any())
            {
                return; // DB has been seeded
            }

            department d1 = new department(1, "Computers");
            department d2 = new department(2, "Electronics");
            department d3 = new department(3, "Fashion");
            department d4 = new department(4, "Books");

            Seller s1 = new Seller(1, "Bob Brown", "bob@gmail.com", new DateTime(1998, 4, 21), 1000.0, d2);
            Seller s2 = new Seller(2, "Maria Green", "maria@gmail.com", new DateTime(1979, 12, 31), 4000.0, d4);
            Seller s3 = new Seller(3, "Alex Gray", "alex@gmail.com", new DateTime(1988, 1, 15), 2000.0, d1);
            Seller s4 = new Seller(4, "Martina Red", "martina@gmail.com", new DateTime(1993, 11, 30), 1500.0, d3);
            Seller s5 = new Seller(5, "Donald Blue", "donald@gmail.com", new DateTime(2000, 1, 9), 9000.0, d2);
            Seller s6 = new Seller(6, "Arthur Yellow", "arthur@gmail.com", new DateTime(1997, 3, 4), 750.0, d4);

            SalesRecord r1 = new SalesRecord(1, new DateTime(2018, 05, 25), 11000.0, SaleStatus.Billed, s1);
            SalesRecord r2 = new SalesRecord(2, new DateTime(2018, 06, 07), 1000.0, SaleStatus.Billed, s2);
            SalesRecord r3 = new SalesRecord(3, new DateTime(2018, 04, 21), 6700.0, SaleStatus.Billed, s3);
            SalesRecord r4 = new SalesRecord(4, new DateTime(2018, 09, 25), 15000.0, SaleStatus.Billed, s4);
            SalesRecord r5 = new SalesRecord(5, new DateTime(2018, 12, 12), 16000.0, SaleStatus.Billed, s2);
            SalesRecord r6 = new SalesRecord(6, new DateTime(2018, 07, 31), 17000.0, SaleStatus.Billed, s3);
            SalesRecord r7 = new SalesRecord(7, new DateTime(2018, 10, 28), 18000.0, SaleStatus.Billed, s5);

            _context.department.AddRange(d1, d2, d3, d4);

            _context.Sellers.AddRange(s1, s2, s3, s4, s5, s6);

            _context.SalesRecord.AddRange(r1, r2, r3, r4, r5, r6, r7);

            _context.SaveChanges();
        }
    }
}
